// Подставляет издание (FREE / PRO / ULTRA) в интерфейс и пишет конфиг Tauri.
//   node scripts/prepare.mjs PRO     -> dist/index.html + src-tauri/tauri.conf.json
//   node scripts/prepare.mjs --all   -> editions/clipper-free|pro|ultra.html (для просмотра в браузере)
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const EDITIONS = ['FREE', 'PRO', 'ULTRA'];
const RE = /const EDITION = '[A-Z]+';/;

const src = readFileSync(join(root, 'ui', 'index.html'), 'utf8');
if (!RE.test(src)) throw new Error("В ui/index.html не найдена строка const EDITION = '...';");
const stamp = ed => src.replace(RE, `const EDITION = '${ed}';`);

const arg = (process.argv[2] || 'FREE').toUpperCase();

if (arg === '--ALL') {
  mkdirSync(join(root, 'editions'), { recursive: true });
  for (const ed of EDITIONS) writeFileSync(join(root, 'editions', `clipper-${ed.toLowerCase()}.html`), stamp(ed));
  console.log('Готово: папка editions/');
  process.exit(0);
}
if (!EDITIONS.includes(arg)) throw new Error(`Издание должно быть одним из: ${EDITIONS.join(', ')}`);

mkdirSync(join(root, 'dist'), { recursive: true });
writeFileSync(join(root, 'dist', 'index.html'), stamp(arg));

const title = arg === 'FREE' ? 'Clipper' : `Clipper ${arg}`;
const conf = {
  $schema: 'https://schema.tauri.app/config/2',
  productName: `Clipper ${arg}`,
  version: '1.0.0',
  identifier: `app.clipper.${arg.toLowerCase()}`,
  build: { frontendDist: '../dist' },
  app: {
    withGlobalTauri: false,
    windows: [{ label: 'main', title, width: 1000, height: 680, minWidth: 760, minHeight: 560, center: true }],
    // Внешних ресурсов и IPC из интерфейса нет, а встроенные style="" требуют отключённого CSP
    security: { csp: null }
  },
  bundle: {
    active: true,
    targets: 'all',
    icon: ['icons/32x32.png', 'icons/128x128.png', 'icons/128x128@2x.png', 'icons/icon.icns', 'icons/icon.ico'],
    category: 'Video',
    shortDescription: 'Клиппер для геймеров',
    windows: { nsis: { installMode: 'currentUser', languages: ['Russian', 'English'], displayLanguageSelector: false } }
  }
};
writeFileSync(join(root, 'src-tauri', 'tauri.conf.json'), JSON.stringify(conf, null, 2) + '\n');
console.log(`Издание ${arg}: dist/index.html и src-tauri/tauri.conf.json готовы`);
