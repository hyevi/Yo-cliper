# Clipper (Tauri 2)

Один интерфейс (`ui/index.html`), три издания: **FREE**, **PRO**, **ULTRA**.
Издание задаёт минимальный тариф: в PRO-сборке PRO открыт сразу, а ключ ULTRA повышает до ULTRA.

## Сборка .exe, .AppImage и .deb через GitHub (проще всего)
1. Создайте репозиторий на GitHub и загрузите туда всё содержимое этой папки.
2. Вкладка **Actions**, затем **Сборка Clipper**, затем **Run workflow**.
3. Через 10–20 минут в артефактах будут 6 наборов: FREE, PRO, ULTRA для Windows и Linux.
   - Windows: установщик `*-setup.exe` и портативный `clipper.exe`
   - Linux: `*.deb` и `*.AppImage`

## Сборка у себя
Нужны Node.js 20+, Rust и системные пакеты Tauri 2 (https://v2.tauri.app/start/prerequisites/).

    npm install
    npm run icons          # один раз: иконки из app-icon.png
    npm run build:free     # или build:pro, build:ultra

Готовые файлы: `src-tauri/target/release/bundle/`.
`.exe` собирается только на Windows, `.deb` и `.AppImage` только на Linux.

## Просмотр без сборки
`npm run editions` кладёт `clipper-free|pro|ultra.html` в папку `editions/`, их можно открыть в браузере.

## Коды активации
Ключи в `ui/index.html` лежат только как хэши (`LIC`). Для продажи проверку нужно перенести на сервер или в Rust.
Закрытие окна прячет его в трей (см. `src-tauri/src/main.rs`).
